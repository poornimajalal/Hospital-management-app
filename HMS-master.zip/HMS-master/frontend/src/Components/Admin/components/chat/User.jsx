import React from 'react'

const User = () => {
  return (
    <div className="chats">
         <div className="userchat">
        <span>Niroj</span>
        <p>online</p>

    </div>

    <div className="userchat">
        <span>Niroj</span>
        <p>online</p>

    </div>
    <div className="userchat">
        <span>Niroj</span>
        <p>online</p>

    </div>
    </div>
  )
}

export default User