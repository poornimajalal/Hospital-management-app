import React from 'react'

const PagenotFound = () => {
  return (
   <center>
     <div>PagenotFound</div>
   </center>
  )
}

export default PagenotFound